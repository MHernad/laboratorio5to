
function submitPokemon(){
    const name = document.getElementById("opa").value;
    const tipo1 = document.getElementById("gangam").value;
    const tipo2 = document.getElementById("style").value;

    console.log(name    , tipo1, tipo2);


    const container = document.createElement("section");

    
    for (let i = 0; i<3; i++){
        const field = document.createElement("input");
        document.append()
    }

   
}