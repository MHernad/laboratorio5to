public class Producto {
    String nombre;
    float precio;

    public Producto(){
        this.nombre = "Teclado";
        this.precio = 500;
    }

    public Producto(String nombre, float precio){
        this.nombre = nombre;
        this.precio = precio;
    }
}
